# ssadmin-web

## Project setup

```bash
yarn install
```

### Compiles and hot-reloads for development

```bash
yarn serve
```

### Compiles and minifies for production

```bash
yarn build
```

### Customize configuration

See [Configuration Reference](https://cli.vuejs.org/config/).
