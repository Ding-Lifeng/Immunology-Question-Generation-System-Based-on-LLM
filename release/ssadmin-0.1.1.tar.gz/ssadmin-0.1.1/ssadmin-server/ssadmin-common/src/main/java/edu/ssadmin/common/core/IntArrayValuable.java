package edu.ssadmin.common.core;

/**
 * 可生成 Int 数组的接口
 * 参考 ruoyi-vue-pro开源项目，https://gitee.com/zhijiantianya/ruoyi-vue-pro
 */
public interface IntArrayValuable {
    int[] array();
}
