package edu.ssadmin.server.controller.admin.permission;

public class PermissionController {
}
