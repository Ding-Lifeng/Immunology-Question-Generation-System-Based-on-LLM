package edu.ssadmin.server.controller;

import edu.ssadmin.common.pojo.CommonResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Demo {
    @GetMapping("/demo")
    public CommonResult<?> getHelloMsg() {
        return CommonResult.success("Hello World");
    }
}
