package edu.ssadmin.server.controller.admin.permission;

public class MenuController {
}
