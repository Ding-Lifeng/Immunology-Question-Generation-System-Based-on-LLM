package edu.ssadmin.server.controller.admin.user;

public class UserController {
}
