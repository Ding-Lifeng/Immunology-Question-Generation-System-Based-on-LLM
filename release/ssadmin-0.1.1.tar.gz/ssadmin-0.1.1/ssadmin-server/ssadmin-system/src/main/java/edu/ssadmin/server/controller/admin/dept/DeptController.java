package edu.ssadmin.server.controller.admin.dept;

public class DeptController {
}
