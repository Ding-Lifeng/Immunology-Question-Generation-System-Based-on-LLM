package edu.ssadmin.server.controller.admin.captcha;

public class CaptchaController {
}
